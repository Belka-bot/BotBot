
Скачайте railway.exe отсюда и положите рядом с этим батником:
https://github.com/railwayapp/cli/releases/latest/download/railway.exe

Затем дважды кликните RunRailwayLogin.bat — откроется PowerShell и начнётся вход в Railway CLI.
