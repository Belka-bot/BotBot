# BelkaBot Railway Ready

FastAPI Webhook bot for Railway.